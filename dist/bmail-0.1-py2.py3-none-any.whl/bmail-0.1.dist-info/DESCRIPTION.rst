# bmail
Black Earth email library

    $ pip install bmail


